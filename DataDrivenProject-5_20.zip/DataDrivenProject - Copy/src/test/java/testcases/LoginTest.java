package testcases;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base.BaseTest;
import utilities.ExcelReader;

public class LoginTest extends BaseTest{
	
	
	@Test(dataProvider="getData")
	public void doLogin(String username, String password) {
		
		type("username_ID",username);
		click("nxtBtn_XPATH");
		type("password_XPATH",password);
		
	}
	
	
	
	
	@DataProvider
	public Object[][] getData() {


		String sheetName = "LoginTest";
		int rowNum = excel.getRowCount(sheetName);
		int colNum = excel.getColumnCount(sheetName);

		Object[][] data = new Object[rowNum - 1][colNum];

		

		for (int rows = 2; rows <= rowNum; rows++) {

			for (int cols = 0; cols < colNum; cols++) {
				// logintest, 0,2
				data[rows - 2][cols] = excel.getCellData(sheetName, cols, rows);

			}

		}

		return data;

	}

	

}
